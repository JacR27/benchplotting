# -*- coding: utf-8 -*-
"""
Created on Thu Jul 16 11:49:21 2015

@author: jrayner
"""
import yaml as ya

class run(ya.YAMLObject):
    yaml_tag= u'!run'
    def __init__(self,name,system,workflow):
        self.name = name
        self.system= system
        self.workflow=workflow
    def __repr__(self):
        return "%s(name=%r, system=%r, workflow=%r)" % (self.__class__.__name__,self.name, self.system,self.workflow)
        
class system(ya.YAMLObject):
    yaml_tag= u'!system'
    def __init__(self,ip,cpu,disk,mem):
        self.ip=ip
        self.cpu=cpu
        self.disk=disk
        self.mem=mem
    def __repr__(self):
        return "%s(ip=%r,cpu=%r,disk=%r,mem=%r)" % (self.__class__.__name__,self.ip,self.cpu,self.disk,self.mem)
        
class workflow(ya.YAMLObject):
    yaml_tag= u'!workflow'
    def __init__(self,name,version,runType,inputFormat):
        self.name=name
        self.version=version
        self.runType=runType
        self.inputFormat=inputFormat
    def __repr__(self):
        "%s(name=%r,version=%r,runType=%r,inputFormat=%r)" % (self.__class__.__name__,self.name,self.version,self.runType,self.inputFormat)
        
class cpu(ya.YAMLObject):
    yaml_tag=u'CPU'
    def __init__(self,model,sockets,cores,threads,GHz):
        self.model =model
        self.sockets=sockets
        self.cores=cores
        self.threads=threads
        self.GHz=GHz
    def __repr__(self):
        "%s(model=%r,sockets=%r,cores=%r,threads=%r,GHz=%r)" % (self.__class__.__name__,self.model,self.sockets,self.cores,self.threads,self.GHz)

class disk(ya.YAMLObject):
    yaml_tag=u'disk'
    def __init__(self,number,size,raidLevel,raidType):
        self.number=number
        self.size=size
        self.raidLevel=raidLevel
        self.raidType=raidType
    def __repr__(self):
        "%s(number=%r,size=%r,raidLevel=%r,raidType=%r)" % (self.__class__.__name__,self.number,self.size,self.raidLevel,self.raidType)
#workflows
W1 = workflow("HAS","2.5.55.1311.HAS","GenerateFASTQ","bcl")
W2 = workflow("HAS","2.5.55.1311.HAS","Alignment","FASTQ")
W3 = workflow("Isis","2.5.55.16.Northstar","Resequence","bcl")
W4 = workflow("Isis","2.6.17.5.Northstar","Resequence","bcl")
W5 = workflow("Isis", "2.5.55.16.Northstar","Tumor normal","bcl")
W6 = workflow("Isis", "2.6.17.6.Northstar","Tumor normal","bcl")
W7 = workflow("Isis", "2.5.55.16.Northstar","GenerateFASTQ","bcl")
W8 = workflow("Isis", "2.6.17.6.Northstar","GenerateFASTQ","bcl")
W9 = workflow("Isis", "2.5.55.16.Northstar","Resequence","FASTQ")
W10 = workflow("Isis", "2.6.17.6.Northstar","Resequence","FASTQ")

cpu1=cpu("Intel(R) Xeon(R) CPU E5-2680 v2",2,10,40,2.80)
cpu2=cpu("Intel(R) Xeon(R) CPU E5-2680 v3",2,12,48,2.50)
cpu3=cpu("Intel(R) Xeon(R) CPU D-1540",1,8,16,2.00)
cpu4=cpu("Intel(R) Xeon(R) CPU E5-2687W v3",2,10,40,3.10)

disk1 = disk(6,5.5,0,"SW")
disk2 = disk(6,14,0,"HW")
disk3 = disk(1,1.8,"NA","NA")
disk4 = disk(6,7.3,0,"SW")
disk5 = disk(9,5.5,0,"SW")
disk6 = disk(6,14,5,"HW")


S1= system("10.46.32.224",cpu1,disk1,132)
S2= system("10.46.30.46",cpu2,disk2,132)
S3= system("10.46.30.52",cpu3,disk3,66)
S4= system("10.46.30.55",cpu4,disk3,132)
S5= system("10.46.30.224",cpu1,disk5,132)
S6= system("10.46.30.46",cpu2,disk6,132)

run1 = run("run1",S1,W2)
#run2 =
#run3
#run4
#run5
#run6
#run7
print (ya.dump(run1,default_flow_style=False))
