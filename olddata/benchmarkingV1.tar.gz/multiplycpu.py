# -*- coding: utf-8 -*-
"""
Created on Thu Jul  9 22:59:28 2015

@author: jrayner
"""

import sys
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
def compSystemcomponet():
    workflow = "W2"
    systems = "S2"
    